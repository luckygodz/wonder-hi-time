
import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Regions from './components/Regions';
import FeatureSection from './components/FeatureSection';
import Footer from './components/Footer';
import OracleChat from './components/OracleChat';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-celestial selection:bg-indigo-500/30">
      <Navbar />
      
      <main>
        <Hero />
        
        <div className="max-w-7xl mx-auto px-4">
          <div className="h-px w-full bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
        </div>
        
        <Regions />
        
        <div className="max-w-7xl mx-auto px-4">
          <div className="h-px w-full bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
        </div>

        <FeatureSection />

        <div className="py-24 text-center">
          <div className="max-w-3xl mx-auto px-4 glass p-12 rounded-[3rem] border-indigo-500/20 glow-purple">
            <h2 className="text-4xl font-bold mb-6 italic">"The constellations are aligning for your arrival."</h2>
            <p className="text-gray-400 mb-10 leading-relaxed text-lg">
              Join 500+ daily active players and start building your cosmic legacy today. 
              Our economy awaits its next master.
            </p>
            <button 
              onClick={() => {
                navigator.clipboard.writeText('celestialcity.top');
                alert('IP copied! See you in-game.');
              }}
              className="px-10 py-5 rounded-2xl bg-indigo-600 text-white font-black text-xl hover:bg-indigo-500 transition-all hover:scale-105 active:scale-95 shadow-xl shadow-indigo-500/20"
            >
              Connect to celestialcity.top
            </button>
          </div>
        </div>
      </main>

      <Footer />
      
      {/* AI Assistant */}
      <OracleChat />
    </div>
  );
};

export default App;
