
import React, { useState, useEffect } from 'react';
import { Sparkles, Menu, X } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'py-4 bg-black/80 backdrop-blur-md border-b border-white/10' : 'py-6'}`}>
      <div className="max-w-7xl mx-auto px-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <span className="text-xl font-bold tracking-tight">Celestial City</span>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">
          <a href="#" className="text-sm font-medium hover:text-indigo-400 transition-colors">Home</a>
          <a href="#regions" className="text-sm font-medium hover:text-indigo-400 transition-colors">Regions</a>
          <a href="#features" className="text-sm font-medium hover:text-indigo-400 transition-colors">Features</a>
          <a href="https://discord.gg/Qr7M7vQmzY" target="_blank" className="text-sm font-medium hover:text-indigo-400 transition-colors">Support</a>
          <button 
            onClick={() => {
              navigator.clipboard.writeText('celestialcity.top');
              alert('IP copied to clipboard!');
            }}
            className="px-6 py-2 rounded-full bg-white text-black font-bold text-sm hover:bg-indigo-500 hover:text-white transition-all"
          >
            Play Now
          </button>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-black/95 border-b border-white/10 p-6 flex flex-col gap-6 animate-in slide-in-from-top-5">
          <a href="#" className="text-lg font-medium" onClick={() => setMobileMenuOpen(false)}>Home</a>
          <a href="#regions" className="text-lg font-medium" onClick={() => setMobileMenuOpen(false)}>Regions</a>
          <a href="#features" className="text-lg font-medium" onClick={() => setMobileMenuOpen(false)}>Features</a>
          <a href="https://discord.gg/Qr7M7vQmzY" target="_blank" className="text-lg font-medium" onClick={() => setMobileMenuOpen(false)}>Discord</a>
          <button className="w-full py-4 rounded-xl bg-indigo-600 font-bold">Play Now</button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
