
import React from 'react';
import { Coins, ShoppingCart, LandPlot, Trophy, Users, Star } from 'lucide-react';

const FeatureSection: React.FC = () => {
  const features = [
    {
      title: 'Celestial Economy',
      description: 'A stable, player-driven economy with dynamic stock markets, crystal trading, and artisan jobs.',
      icon: <Coins className="w-8 h-8 text-yellow-400" />,
    },
    {
      title: 'Global Markets',
      description: 'List your items on the cross-region auction house. Buy in Europe, sell in America, profit in Asia.',
      icon: <ShoppingCart className="w-8 h-8 text-indigo-400" />,
    },
    {
      title: 'Divine Claims',
      description: 'Protect your creations with an intuitive land claiming system. Build your empire without fear of griefing.',
      icon: <LandPlot className="w-8 h-8 text-green-400" />,
    },
    {
      title: 'Monthly Seasons',
      description: 'Compete in server-wide events and leaderboard challenges for exclusive celestial ranks and rewards.',
      icon: <Trophy className="w-8 h-8 text-orange-400" />,
    },
    {
      title: 'Vibrant Community',
      description: 'Join thousands of players in our active Discord and in-game chat. Make friends and form alliances.',
      icon: <Users className="w-8 h-8 text-pink-400" />,
    },
    {
      title: 'Premium Experience',
      description: 'Custom plugins, balanced gameplay, and a dedicated staff team committed to the player experience.',
      icon: <Star className="w-8 h-8 text-blue-400" />,
    },
  ];

  return (
    <div id="features" className="py-24">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-12">
          {features.map((feature, i) => (
            <div key={i} className="flex flex-col gap-4">
              <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
                {feature.icon}
              </div>
              <h3 className="text-2xl font-bold">{feature.title}</h3>
              <p className="text-gray-400 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FeatureSection;
