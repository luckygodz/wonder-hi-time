
import React, { useState, useEffect } from 'react';
import { Copy, Check, Shield, Zap, Globe } from 'lucide-react';
import { fetchServerStatus } from '../services/mcStatusService';
import { ServerStatus } from '../types';

const Hero: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [status, setStatus] = useState<ServerStatus | null>(null);
  const serverIp = 'celestialcity.top';

  useEffect(() => {
    fetchServerStatus().then(setStatus);
    const interval = setInterval(() => {
      fetchServerStatus().then(setStatus);
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const copyIp = () => {
    navigator.clipboard.writeText(serverIp);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative pt-32 pb-20 overflow-hidden">
      {/* Background Orbs */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-purple-900/10 rounded-full blur-3xl -z-10 animate-pulse"></div>
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-indigo-900/10 rounded-full blur-3xl -z-10"></div>

      <div className="max-w-7xl mx-auto px-4 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-sm font-medium mb-8 text-indigo-300">
          <Globe className="w-4 h-4" />
          <span>Multi-Region Global Nodes</span>
        </div>
        
        <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-b from-white to-gray-500 bg-clip-text text-transparent">
          Celestial City
        </h1>
        
        <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-10 leading-relaxed">
          Embark on a divine journey in the ultimate Minecraft economy experience. 
          Connect to low-latency nodes across <span className="text-indigo-400 font-semibold">Europe, America, and Asia</span>.
        </p>

        <div className="flex flex-col md:flex-row items-center justify-center gap-4 mb-12">
          <div className="relative group w-full md:w-auto">
            <button 
              onClick={copyIp}
              className="w-full md:w-80 flex items-center justify-between px-6 py-4 rounded-xl bg-white text-black font-bold text-lg hover:bg-gray-100 transition-all duration-300"
            >
              <span className="flex-1 text-center font-mono">{serverIp}</span>
              {copied ? <Check className="w-5 h-5 text-green-600" /> : <Copy className="w-5 h-5" />}
            </button>
            <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity text-sm text-gray-500">
              Click to copy IP
            </div>
          </div>
          
          <a 
            href="https://discord.gg/Qr7M7vQmzY" 
            target="_blank"
            className="w-full md:w-auto px-8 py-4 rounded-xl border border-white/20 bg-white/5 hover:bg-white/10 font-bold transition-all text-lg"
          >
            Join Discord
          </a>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto text-left">
          <div className="glass p-6 rounded-2xl">
            <div className="flex items-center gap-3 mb-2">
              <Zap className="w-5 h-5 text-yellow-400" />
              <span className="text-gray-400 text-sm font-medium">Status</span>
            </div>
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${status?.online ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]' : 'bg-red-500'}`}></div>
              <span className="font-bold">{status?.online ? 'Online' : 'Loading...'}</span>
            </div>
          </div>

          <div className="glass p-6 rounded-2xl">
            <div className="flex items-center gap-3 mb-2">
              <Globe className="w-5 h-5 text-indigo-400" />
              <span className="text-gray-400 text-sm font-medium">Players</span>
            </div>
            <div className="font-bold text-xl">
              {status?.players.online || 0} <span className="text-gray-500 text-sm">/ {status?.players.max || 1000}</span>
            </div>
          </div>

          <div className="glass p-6 rounded-2xl">
            <div className="flex items-center gap-3 mb-2">
              <Shield className="w-5 h-5 text-blue-400" />
              <span className="text-gray-400 text-sm font-medium">Version</span>
            </div>
            <div className="font-bold">{status?.version || '1.20.x'}</div>
          </div>

          <div className="glass p-6 rounded-2xl">
            <div className="flex items-center gap-3 mb-2">
              <Zap className="w-5 h-5 text-purple-400" />
              <span className="text-gray-400 text-sm font-medium">Uptime</span>
            </div>
            <div className="font-bold">99.9%</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
