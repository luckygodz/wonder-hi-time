
import React from 'react';
import { ShieldCheck, MapPin, Signal } from 'lucide-react';
import { RegionInfo } from '../types';

const regions: RegionInfo[] = [
  {
    id: 'eu',
    name: 'Europe',
    location: 'Frankfurt, Germany',
    flag: '🇪🇺',
    description: 'Lightning-fast connection for our European community with dedicated enterprise-grade hardware.'
  },
  {
    id: 'us',
    name: 'America',
    location: 'New York, USA',
    flag: '🇺🇸',
    description: 'Optimized routing for North and South American players, ensuring smooth economy interactions.'
  },
  {
    id: 'as',
    name: 'Asia',
    location: 'Singapore',
    flag: '🇸🇬',
    description: 'Expanding our reach to the East with high-performance nodes in the heart of Asia Pacific.'
  }
];

const Regions: React.FC = () => {
  return (
    <div id="regions" className="py-24 bg-black/50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">A Global Network</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            We don't believe in lag. Our distributed architecture ensures you play with the lowest possible latency, no matter where you are in the world.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {regions.map((region) => (
            <div key={region.id} className="glass p-8 rounded-3xl group hover:border-indigo-500/50 transition-all duration-500">
              <div className="text-4xl mb-6 grayscale group-hover:grayscale-0 transition-all duration-500">{region.flag}</div>
              <h3 className="text-2xl font-bold mb-2 flex items-center gap-2">
                {region.name}
                <Signal className="w-4 h-4 text-green-500 animate-pulse" />
              </h3>
              <div className="flex items-center gap-2 text-indigo-400 text-sm font-medium mb-4">
                <MapPin className="w-4 h-4" />
                {region.location}
              </div>
              <p className="text-gray-400 leading-relaxed mb-6">
                {region.description}
              </p>
              <div className="pt-6 border-t border-white/5 flex items-center gap-2 text-sm text-gray-500">
                <ShieldCheck className="w-4 h-4" />
                DDoS Protected Hardware
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Regions;
