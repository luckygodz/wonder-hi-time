
import React from 'react';
import { Sparkles, Github, Twitter, MessageSquare } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="border-t border-white/5 py-16 bg-black">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <Sparkles className="w-6 h-6 text-indigo-500" />
              <span className="text-xl font-bold">Celestial City</span>
            </div>
            <p className="text-gray-500 max-w-sm mb-6">
              The world's first multi-region premium economy server. Built by players, for players. Dedicated to low-latency and high-quality gameplay.
            </p>
            <div className="flex gap-4">
              <a href="#" className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"><Twitter className="w-5 h-5" /></a>
              <a href="https://discord.gg/Qr7M7vQmzY" target="_blank" className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"><MessageSquare className="w-5 h-5" /></a>
              <a href="#" className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"><Github className="w-5 h-5" /></a>
            </div>
          </div>
          
          <div>
            <h4 className="font-bold mb-6 uppercase text-xs tracking-widest text-gray-400">Navigation</h4>
            <ul className="space-y-4 text-gray-500 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Home</a></li>
              <li><a href="#features" className="hover:text-white transition-colors">Features</a></li>
              <li><a href="#regions" className="hover:text-white transition-colors">Regions</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Store</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6 uppercase text-xs tracking-widest text-gray-400">Legal</h4>
            <ul className="space-y-4 text-gray-500 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Cookie Policy</a></li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-gray-500 text-xs">
          <p>© 2024 Celestial City. Not an official Minecraft product. Not approved by or associated with Mojang or Microsoft.</p>
          <p>Hand-crafted for the stars.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
