
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const SYSTEM_INSTRUCTION = `
You are the "Celestial Oracle," the AI assistant for the Celestial City Minecraft Server.
Your personality is mystical, helpful, and welcoming. 
Server Details:
- Server IP: celestialcity.top
- Regions: Europe (EU), America (US), Asia (AS). Dedicated nodes in each for low latency.
- Gameplay: Premium Economy server.
- Features: Player-driven markets, custom jobs, land claiming, and celestial-themed ranks.
- Discord: https://discord.gg/Qr7M7vQmzY

Always encourage players to join the server and the Discord. Keep responses concise but thematic.
`;

export const getOracleResponse = async (prompt: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
        topP: 0.9,
      },
    });
    return response.text || "The stars are silent. Try again later, traveler.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The cosmic connection is weak. Please join our Discord for manual assistance!";
  }
};
